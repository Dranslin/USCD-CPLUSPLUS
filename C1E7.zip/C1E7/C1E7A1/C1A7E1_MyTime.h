/*
 * Nicholas Patience U07985691
 * Nickspatience@gmail.com
 * C/C++ Programming I : Fundamental Programming Concepts
 * 132297 Ray Mitchell
 * 08/23/2018
 * C1A7E1_MyTime.h
 * Win 10
 * Visual C++ 2017
 *
 * Structure for MyTime that has hours, minutes and seconds.
 */

#ifndef C1A7E1_MYTIME_H
#define C1A7E1_MYTIME_H
struct MyTime { int hours, minutes, seconds; };
#endif // !C1A7E1_MYTIME_H
