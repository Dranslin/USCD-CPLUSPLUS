/*
 * Nicholas Patience U07985691
 * Nickspatience@gmail.com
 * C/C++ Programming II : Dynamic Memory and File I/O Concepts
 * 134312 Ray Mitchell
 * 10/06/2018
 * C2A2E4_Reverse.cpp
 * Win 10
 * Visual C++ 2017
 *
 * 
 */

#include <fstream>
#include <iostream>

inline bool testSeparator(const char *testVal)
{
    return ((isspace(*testVal)) || (ispunct(*testVal))) ? false : true;
}

int Reverse(std::ifstream &infile, const int level)
{
    if (infile.is_open())
    {
        std::cout << "open";
    }

    char thisChar;
    infile.get(thisChar);
    if (testSeparator(&thisChar))
    {
        std::cout << thisChar;
        //return (int)thisChar;
    }
    else
    {
        int thisSeparator = Reverse(infile, level + 1);
        std::cout << thisSeparator;
        //return (level == 1) ? (int)toupper((char)thisSeparator) : thisSeparator;
    }
    return 0;
}
