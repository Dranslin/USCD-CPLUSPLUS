/*
 * Nicholas Patience U07985691
 * Nickspatience@gmail.com
 * C/C++ Programming II : Dynamic Memory and File I/O Concepts
 * 134312 Ray Mitchell
 * 11/3/2018
 * C2A6E1_GetPointers.c
 * Win 10
 * Visual C++ 2017
 *
 * 
 */

#include <stdio.h>

int(*GetPrintfPointer(void))(const char *format, ...)
{
    int (*pPrintf)(char *, ...);
    int result;

    pPrintf = printf;
    result = (*pPrintf)(char *test, ...);
}

int(*GetPutsPointer(void))(const char *str)
{
    int(*pPuts)();
    int result;
    
    pPuts = puts(char *str);
    result = (*pPuts)();
}
