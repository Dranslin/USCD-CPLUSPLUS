/*
 * Nicholas Patience U07985691
 * Nickspatience@gmail.com
 * C/C++ Programming II : Dynamic Memory and File I/O Concepts
 * 134312 Ray Mitchell
 * 10/06/2018
 * C2A2E2_Rotate.cpp
 * Win 10
 * Visual C++ 2017
 *
 * Provides macro to get size of number of bits of storage used
 * for the provided object or type.
 */

unsigned Rotate(unsigned object, int count)
{
    int bits = CountIntBitsF();

    if (count >= 0)     // Positive, shift to the right.
    {

    }
    else                // Negitive, shift to the left.
    {

    }
}