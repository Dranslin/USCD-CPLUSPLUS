/*
 * Nicholas Patience U07985691
 * Nickspatience@gmail.com
 * C/C++ Programming II : Dynamic Memory and File I/O Concepts
 * 134312 Ray Mitchell
 * 10/12/2018
 * C2A3E4_ParseStringFields.c
 * Win 10
 * Visual C++ 2017
 *
 * 
 */

#include <stdio.h>

void ParseStringFields(FILE *fp)
{

}