/*
 * Nicholas Patience U07985691
 * Nickspatience@gmail.com
 * C/C++ Programming II : Dynamic Memory and File I/O Concepts
 * 134312 Ray Mitchell
 * 10/12/2018
 * C2A3E4_OpenFile.c
 * Win 10
 * Visual C++ 2017
 *
 * Opens the file who's name is specified in filename, or errors out
 * and terminates the program.
 */

#include <stdio.h>


FILE *OpenFile(const char *fileName)
{
    FILE *source;
    source = fopen(fileName, 'r');

    if (!source)
    {
        printf("File %s failed to open.", fileName, stderr);
        exit();
    }
    return source;
}
