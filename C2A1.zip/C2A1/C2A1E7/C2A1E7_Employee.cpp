/*
* Nicholas Patience U07985691
* Nickspatience@gmail.com
* C/C++ Programming II : Dynamic Memory and File I/O Concepts
* 134312 Ray Mitchell
* 10/01/2018
* C2A1E7_Employee.cpp
* Win 10
* Visual C++ 2017
*
*
*/

#include "C2A1E7_Employee.h"

void Employee::Set(const char *value)
{

}