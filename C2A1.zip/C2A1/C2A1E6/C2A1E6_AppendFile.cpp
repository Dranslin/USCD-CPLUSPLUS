/*
* Nicholas Patience U07985691
* Nickspatience@gmail.com
* C/C++ Programming II : Dynamic Memory and File I/O Concepts
* 134312 Ray Mitchell
* 10/01/2018
* C2A1E6_AppendFile.cpp
* Win 10
* Visual C++ 2017
*
*
*/

int AppendFile(const char *inFile, const char *outFile)
{

}