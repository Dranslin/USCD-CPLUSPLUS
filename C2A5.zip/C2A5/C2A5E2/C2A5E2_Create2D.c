/*
 * Nicholas Patience U07985691
 * Nickspatience@gmail.com
 * C/C++ Programming II : Dynamic Memory and File I/O Concepts
 * 134312 Ray Mitchell
 * 10/27/2018
 * C2A5E2_Create2D.c
 * Win 10
 * Visual C++ 2017
 *
 *
 */

#include <stdio.h>

Type **Create2D(size_t rows, size_t cols)
{

}

void Free2D(void *p)
{

}
