/*
 * Nicholas Patience U07985691
 * Nickspatience@gmail.com
 * C/C++ Programming II : Dynamic Memory and File I/O Concepts
 * 134312 Ray Mitchell
 * 11/9/2018
 * C2A7E4_OpenTemporaryFile.c
 * Win 10
 * Visual C++ 2017
 *
 * 
 */

#include <stdio.h>
#include <stdlib.h>

FILE *OpenTemporaryFile(void)
{
    FILE *source = tmpfile();

    if (source == NULL)
    {
        // Fail condition: Alert and exit program.
        fprintf(stderr, "Temp file failed to open.");
        exit(EXIT_FAILURE);
    }
    return source;
}
