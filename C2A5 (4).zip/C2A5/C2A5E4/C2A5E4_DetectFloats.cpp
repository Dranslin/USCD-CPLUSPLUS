/*
 * Nicholas Patience U07985691
 * Nickspatience@gmail.com
 * C/C++ Programming II : Dynamic Memory and File I/O Concepts
 * 134312 Ray Mitchell
 * 10/27/2018
 * C2A5E4_DetectFloats.cpp
 * Win 10
 * Visual C++ 2017
 *
 *
 */

#include "C2A5E4_StatusCode-Driver.h"

StatusCode DetectFloats(const char *chPtr)
{
    enum States
    {
        START,
        PREFIX_START,
        PREFIX,
        NO_WHOLE,
        WHOLE,
        FRACT,
        EXPONENT,
        SIGNED,
        DIGIT,
        FLOAT,
        LONG_DOUBLE,
        DOUBLE
    };


    StatusCode returnV = NO_MATCH;
    return (returnV);
}
