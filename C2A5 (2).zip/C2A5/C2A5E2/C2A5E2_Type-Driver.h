#ifndef C2A5E2_TYPE_DRIVER_H
#define C2A5E2_TYPE_DRIVER_H

/***  YOU DO NOT NEED TO UNDERSTAND THE CODE IN THIS FILE TO WRITE YOURS  ***/

/******************** DO NOT MODIFY THIS FILE IN ANY WAY ********************/
/******************** DO NOT MODIFY THIS FILE IN ANY WAY ********************/
/******************** DO NOT MODIFY THIS FILE IN ANY WAY ********************/

//****************************************************************************
// Everything in this file was written to help test/verify your code and must
// not be altered in any way.  Do not rename this file or copy anything from
// it into your file(s).  This file does not necessarily represent good coding
// technique, proper formatting/style, or meet the requirements your code must
// meet.  You do not need to understand the code in this file to write yours.
//
// You may #include this file in your file(s) as necessary.
//****************************************************************************

#define ELEMENTS 9
// Type to use for dynamic array elements...
typedef signed char Type[ELEMENTS];
#undef ELEMENTS

#endif
