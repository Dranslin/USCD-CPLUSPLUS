/*
 * Nicholas Patience U07985691
 * Nickspatience@gmail.com
 * C/C++ Programming II : Dynamic Memory and File I/O Concepts
 * 134312 Ray Mitchell
 * 10/27/2018
 * C2A5E2_Create2D.c
 * Win 10
 * Visual C++ 2017
 *
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "C2A5E2_Type-Driver.h"

Type **Create2D(size_t rows, size_t cols)
{
    // P
    //Type **toArray;
    Type **toArray, **traveler, **endOfArray;

    // Assignment wants to allocate entire space for pointer array at once.
    toArray = (Type **)malloc(sizeof(Type *) * (rows + rows * cols));
    if (toArray == NULL)
    {
        fputs("Memory alloc failed.\n", stderr);
        exit(EXIT_FAILURE);
    }

    // Move into the pointer array and begin allocating memory for each row?
    for (endOfArray = toArray + rows, traveler = toArray; traveler < endOfArray; ++traveler)
    {
        traveler = (Type *)malloc(sizeof(Type) * cols);
        if (traveler == NULL)
        {
            fputs("Memory alloc failed.\n", stderr);
            exit(EXIT_FAILURE);
        }
    }

    /*toArray = (Type **)SafeMalloc(rows * sizeof(Type *));
    cols *= sizeof(Type);
    for (endOfArray = toArray + rows, p1 = toArray; p1 < endOfArray; ++p1)
    {
        *p1 = (Type *)SafeMalloc(cols);
    }
*/
    return (toArray);
}

void Free2D(void *p)
{
    Type **toLevel, **endOfArray;

    //for (endOfArray = p + (int)sizeof(p), toLevel = p; toLevel < endOfArray; ++toLevel)
    //{
    //    free(*toLevel);
    //}

    free(p);
}

//void *SafeMalloc(size_t size)
//{
//    void *vp;
//    if ((vp = malloc(size)) == NULL)
//    {
//        fputs("Memory alloc failed\n", stderr);
//        exit(EXIT_FAILURE);
//    }
//}